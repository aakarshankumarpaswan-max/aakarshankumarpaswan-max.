# Play Console: ready answers (check each against the real form before you submit)

These are the honest answers for the game **as it is now** (no ads, no in-app purchases, no accounts, offline).
If you later add ads or purchases, change the answers and the privacy policy first.

## App content
| Question | Answer |
|---|---|
| App or game? | Game |
| Free or paid? | Free (you cannot change a free app to paid later) |
| Category | Games > Action |
| Privacy policy URL | Host `privacy-policy.html` (GitHub Pages / Google Sites / your own site), fill the yellow fields first, and paste the link |
| Contains ads? | No (until you add AdMob) |
| In-app purchases? | No (until you add them) |
| Target audience | 13+ (choose age groups 13-15, 16-17, 18+). Do NOT pick "under 13", that triggers the Families policy |
| Appeals to children? | No |
| News app / COVID / government / financial / health app? | No to all |
| App access (login needed?) | All functionality is available without login |
| Advertising ID | Not used: choose "No" |

## Data safety form
- Does your app collect or share any of the required user data types? **No**
- (Because nothing leaves the device. If you add AdMob, you must answer Yes and list the data the ad SDK collects.)
- Is all data encrypted in transit? Not applicable (no data sent).
- Data deletion: not applicable.

## Content rating (IARC questionnaire)
Answer honestly. For this game:
- Violence: **Yes**, fantasy/cartoon violence against zombies (shooting, explosions). **No** blood or gore (the game shows green sparks only), no realistic human violence.
- Weapons: **Yes**, fictional guns, a freeze ray and grenades.
- Sexual content / nudity: No. Profanity: No. Drugs, alcohol, tobacco: No. Gambling: No.
- User-generated content / chat / sharing location: No.
- Digital purchases / ads: No.
The rating is decided by the questionnaire, expect something like Teen / PEGI 12. Do not try to answer "no violence".

## Release
- Upload the **.aab** file (not an .apk).
- Turn on Google Play App Signing (default) and **keep a backup of your upload keystore and its passwords**. If you lose it you cannot update the app.
- Target API level: the setup script raises it to 36 when needed; Play requires a current target for new apps. If Play Console shows an API warning, update Android Studio and the Capacitor packages, then rebuild.
- Countries: pick the countries you want (India etc.).

## Before production
- Personal developer accounts must first run a **closed test with at least 12 testers for 14 continuous days** (see `tester-invite-message.md`). Only then can you apply for production access.
- Organisation accounts (with a D-U-N-S number) are not subject to that rule.
