# Google Play store listing (English)

**App name (max 30):** Zombie Maze Escape

**Short description (max 80, 67 used):**
Hide, run and shoot your way out of zombie mazes across 100 levels.

**Full description (max 4000):**

Find the exit. Don't get caught.

Zombie Maze Escape is a fast, tense maze-survival game. Every level is a freshly generated maze full of zombies. Run through the corridors, hide behind walls, and reach the exit door before they reach you.

SMART ZOMBIES
Zombies only chase what they can actually see. Break their line of sight behind a wall and they lose you: they search the last place they saw you, then slowly walk back home. Make noise and they come to investigate.

100 LEVELS, 10 CITIES
Fight your way through ten themed cities, from the Ruined Town to the glowing Last Z Core. A new city opens every 10 levels, with more zombies, faster zombies and bigger mazes as you go.

UNLOCK WEAPONS
Clear level 10 to unlock your first gun, and a new weapon opens every 10 levels after that:
- Pistol: reliable and quiet
- Shotgun: six pellets at close range
- Rifle: rapid fire
- Freeze Ray: freezes zombies, completely silent
- Grenade: a big blast that hits many zombies
Shots are loud, so use them wisely.

CHOOSE YOUR SURVIVOR
Play as the Girl, the Boy, Grandpa, the Explorer, the Astronaut or the Superhero. New survivors unlock as you progress.

FEATURES
- Real-time 3D-style characters with walking and running animations
- Floating touch joystick: touch anywhere to move
- Auto-aim FIRE button
- Hide-and-seek zombie AI with sight, search and return-home behaviour
- Camera zoom and edge arrows for big mazes
- Your progress is saved automatically
- Works fully offline. No account needed.

Stay low, stay quiet, and get out alive.

**What's new (release notes):**
First release: 100 levels, 10 cities, 6 survivors and 5 weapons.

**Category:** Games > Action
**Tags (pick from Play's list):** Action, Survival, Maze, Zombie (if available)
**Contact email / website / privacy policy URL:** you must fill these in the Play Console.
