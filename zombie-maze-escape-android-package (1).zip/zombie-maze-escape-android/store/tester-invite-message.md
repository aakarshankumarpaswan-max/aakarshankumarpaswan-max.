# Message to send to your 12 testers (copy & paste)

## Hindi
नमस्ते! मैंने एक गेम बनाया है "Zombie Maze Escape" और उसे Google Play पर डालने के लिए 12 टेस्टर चाहिए। आपसे सिर्फ़ ये करना है:

1. यह लिंक अपने फ़ोन में खोलिए और "Become a tester" दबाइए: [PLAY CONSOLE का टेस्ट लिंक यहाँ डालें]
2. उसी Google अकाउंट से Play Store में गेम इंस्टॉल कीजिए (लिंक पर दिया बटन दबाइए)।
3. **अगले 14 दिन तक इसे इंस्टॉल रहने दीजिए** (अनइंस्टॉल मत कीजिए) और बीच-बीच में कुछ दिन खोलकर खेल लीजिए।
4. कुछ गड़बड़ दिखे (अटकना, बंद हो जाना) तो मुझे बता दीजिए।

बहुत धन्यवाद! 🙏

## English
Hi! I made a game, "Zombie Maze Escape", and Google requires 12 testers before I can publish it. Please:
1. Open this link on your phone and tap "Become a tester": [PASTE YOUR PLAY CONSOLE TEST LINK]
2. Install the game from Play Store with the same Google account.
3. Keep it installed for the next 14 days and open it a few times.
4. Tell me if anything crashes or freezes.
Thank you!

## Tips for you
- Use real people with real Android phones, each with a different Google account. Add their Gmail addresses to a tester list in Play Console (Testing > Closed testing > Testers).
- The 14 days must be continuous with at least 12 testers opted in the whole time. If someone leaves, add replacements.
- Ask testers to actually open the game a few times (installing alone is the risky minimum).
- After 14 days, Play Console shows "Apply for production". Answer its questions honestly (what feedback you got, what you fixed).
