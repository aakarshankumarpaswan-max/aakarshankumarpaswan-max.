// One command setup:  npm run setup
// Installs Capacitor, creates the Android project, applies the Play-Store friendly tweaks, syncs the game.
const {execSync}=require('child_process');
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
process.chdir(root);
const run=(c,opt)=>{console.log('\n> '+c);execSync(c,Object.assign({stdio:'inherit'},opt||{}))};

const cfg=JSON.parse(fs.readFileSync('capacitor.config.json','utf8'));
if(/yourname/i.test(cfg.appId)){
  console.error('\nSTOP: open capacitor.config.json and change "appId" (for example com.rahul.zombiemazeescape).\nThe appId can NOT be changed after the app is published on Google Play.');
  process.exit(1);
}
if(parseInt(process.versions.node)<20)console.warn('Warning: use a current Node.js LTS version (20 or newer).');

run('npm install');
if(!fs.existsSync('android'))run('npx cap add android');

// icons (needs assets/icon-only.png) - not fatal if it fails
try{run('npx @capacitor/assets generate --android --iconBackgroundColor "#0b140e" --iconBackgroundColorDark "#0b140e"')}
catch(e){console.warn('\nIcon generation skipped (you can run it later). The game itself is fine.')}

// ---- tweaks ----
const find=(dir,name)=>{for(const f of fs.readdirSync(dir)){const p=path.join(dir,f);const s=fs.statSync(p);
  if(s.isDirectory()){const r=find(p,name);if(r)return r}else if(f===name)return p}return null};

// 1) portrait only
const man='android/app/src/main/AndroidManifest.xml';
let m=fs.readFileSync(man,'utf8');
if(!/screenOrientation/.test(m)){m=m.replace('<activity','<activity\n            android:screenOrientation="portrait"');fs.writeFileSync(man,m);console.log('OK  portrait orientation set')}

// 2) full-screen (hide status/navigation bars) + keep the screen on while playing
const ma=find('android/app/src/main/java','MainActivity.java');
if(ma){
  const src=fs.readFileSync(ma,'utf8');
  if(/extends\s+BridgeActivity\s*\{\s*\}/.test(src)&&!/WindowInsetsControllerCompat/.test(src)){
    const pkg=(src.match(/package\s+([\w.]+);/)||[])[1];
    fs.writeFileSync(ma,`package ${pkg};

import android.os.Bundle;
import android.view.WindowManager;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
            c.hide(WindowInsetsCompat.Type.systemBars());
            c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        }
    }
}
`);console.log('OK  full-screen + keep-screen-on added to MainActivity.java')}
  else console.log('NOTE MainActivity.java was not the default file - skipped full-screen tweak (see README, step "Full screen").');
}

// 3) Google Play needs the newest target API for new apps
const vg='android/variables.gradle';
if(fs.existsSync(vg)){
  let v=fs.readFileSync(vg,'utf8');
  const bump=k=>{v=v.replace(new RegExp('('+k+'\\s*=\\s*)(\\d+)'),(a,p,n)=>{if(parseInt(n)<36){console.log('OK  '+k+' '+n+' -> 36');return p+'36'}return a})};
  bump('compileSdkVersion');bump('targetSdkVersion');
  fs.writeFileSync(vg,v);
}

run('npx cap sync android');
console.log('\nDONE.  Next:  npm run open   (opens Android Studio) -> plug in your phone -> press Run.\nThen build the signed AAB (see README_HINDI.md, step 5).');
